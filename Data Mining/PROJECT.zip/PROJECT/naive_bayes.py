import pandas as pd
from sklearn.naive_bayes import MultinomialNB
from sklearn import preprocessing

def tanspose(train_set):
    data_set = list(map(list,zip(*train_set)))
    return data_set



def encode(train_set,classes):
    transposed_data_set = tanspose(train_set)

    encode = preprocessing.LabelEncoder()

    encoded_data_set = []

    for key, values in enumerate(transposed_data_set):
        encoded_data_set.append(list(encode.fit_transform(values)))
        encoded_class = list(encode.fit_transform(classes))

    transpose_encoded_data_set = tanspose(encoded_data_set)
    return transpose_encoded_data_set, encoded_class






def seperate_class(train_set):
    classes = []
    for key,values in enumerate(train_set):
        classes.append(train_set[key].pop())
    return train_set,classes

def main():
    train = pd.read_csv("train_data.csv")
    print("\n The trainig data is : \n",train)
    train_set = train.values.tolist()

    test = pd.read_csv("test_data.csv")
    print("\n The test data is :  \n",test)
    test_set = test.values.tolist()

    train_set,classes = seperate_class(train_set)


    for i in test_set:
        train_set.append(i)

    encoding_data_set,encoding_classes = encode(train_set,classes)

    encoded_test_set = encoding_data_set.pop()

    clf = MultinomialNB(alpha=1.0)
    clf.fit(encoding_data_set, encoding_classes)
    prediction = clf.predict([encoded_test_set])
    print("\n The predicted class is:  ",classes[encoding_classes.index(prediction)])




if __name__ == '__main__':
    main()