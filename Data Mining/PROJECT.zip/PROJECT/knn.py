import pandas as pd
from operator import itemgetter



def difference(train_data,test_data):           #calculate the  distance
    if (train_data == test_data):
        return 0
    else:
        return 1



def hamming_distance(train_data,test_data):
    distances = 0

    length_test_data = len(test_data)

    for i in range(length_test_data):
        distances += difference(train_data[i],test_data[i])         #
    return distances




def neighbour(train_data,test_data,k):
    distancesss = [ ]
    length_train_data = len(train_data)

    for i in range(length_train_data):
        distance = hamming_distance(train_data[i],test_data)
        distancesss.append((train_data[i],distance))

    distancesss.sort(key = itemgetter(1))


    nearest_neighbour = [ ]
    for i in range(k):
        nearest_neighbour.append(distancesss[i][0])
    return nearest_neighbour


def main():
    train = pd.read_csv("train_data.csv")
    print("\n the training data set is : \n",train)

    test = pd.read_csv("test_data.csv")
    print("\n the testing data is  : \n",test)

    test_data = test.values.tolist()
    train_data = train.values.tolist()

    k = int(input("\n enter the number of neighbours: "))

    length_test_data = len(test_data)

    for i in range (length_test_data) :
        neighbours = neighbour(train_data,test_data[i],k)

    neighbour_class = [ ]
    for key,value in enumerate(neighbours):
        neighbour_class.append(neighbours[key][len(neighbours[key])-1])


    neighbour_class_count = []
    for i in set(neighbour_class):
        neighbour_class_count.append([i,neighbour_class.count(i)])


    neighbour_class_count.sort(key = itemgetter(1))
    print(neighbour_class_count)

    predict_class = [ ]
    predict_class.append(max(neighbour_class_count,key = itemgetter(1))[0])

    print("\n the test_data belongs to the class : ",predict_class[0])



if __name__ == '__main__':
    main()
