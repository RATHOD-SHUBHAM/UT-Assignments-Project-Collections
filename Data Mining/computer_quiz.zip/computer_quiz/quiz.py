import pandas as pd
import numpy as np
from operator import itemgetter

def hamming_distance(train_data,test_data):
    if (train_data == test_data):
        return 0
    else:
        return 1

def distancess(train_data,test_data):
    distance = 2*(abs(train_data - test_data)/(train_data + test_data))
    return distance


def calculate(train_data, test_data):
    h_distance = 0
    a_distances = 0
    length_test_data = len(test_data)

    for i in range(length_test_data):
        if ((isinstance(train_data[i], str)) and (isinstance(test_data[i], str))):
            h_distance += hamming_distance(train_data[i], test_data[i])
        else:
            a_distances += distancess(train_data[i] + 1, test_data[i] + 1)
    return h_distance + a_distances

def attribute_distance(train_row,test_data):
    length_test_data = len(test_data)
    distance = calculate(train_row,test_data)
    return distance


def neighbour(train_data, test_data, k):
    length_train_data = len(train_data)
    neighbours = []

    for i, el in enumerate(train_data):
        distance = attribute_distance(train_data[i], test_data)
        neighbours.append((train_data[i], distance))

    neighbours.sort(key=itemgetter(1))

    nearest_neighbour = []
    for i in range(k):
        nearest_neighbour.append(neighbours[i][0])
    return nearest_neighbour


def missing(neighbours, position):
    neighbour = [ ]
    for key,value in enumerate(neighbours):
        neighbour.append(neighbours[key][position])
    neighbour_class_count = []
    for i in set(neighbour):
        neighbour_class_count.append([i,neighbour.count(i)])
    neighbour_class_count.sort(key = itemgetter(1))
    predict_class = [ ]
    predict_class.append(max(neighbour_class_count,key = itemgetter(1))[0])
    return predict_class[0]

def distance_knn(train_set,test_set):
    distances = 0

    length_test_data = len(test_set)

    for i in range(length_test_data):
        distances += hamming_distance(train_set[i],test_set[i])
    return distances


def neighbour_knn(train_data,test_data,k):
    distancesss = [ ]
    length_train_data = len(train_data)

    for i in range(length_train_data):
        distance = distance_knn(train_data[i],test_data)
        distancesss.append((train_data[i],distance))

    distancesss.sort(key = itemgetter(1))


    nearest_neighbour = [ ]
    for i in range(k):
        nearest_neighbour.append(distancesss[i][0])
    return nearest_neighbour


def knn(train, test):
    k = 3

    length_test_data = len(test)
    all_neighbours = []
    for i in range(length_test_data):
        neighbours = neighbour_knn(train, test[i], k)

        neighbour_class = []
        for key, value in enumerate(neighbours):
            neighbour_class.append(neighbours[key][len(neighbours[key]) - 1])

        neighbour_class_count = []
        for x in set(neighbour_class):
            neighbour_class_count.append([x, neighbour_class.count(x)])

        neighbour_class_count.sort(key=itemgetter(1))

        predict_class = max(neighbour_class_count, key=itemgetter(1))[0]
        print("the class labell predicted is : ", predict_class)
        test[i].append(predict_class)

    print("\n the test_data belongs to the class : \n", test)


def main():
    train_data = pd.read_csv("train.csv", header=None)

    col_name = ["Age", "WorkClass", "fnlwgt", "Education", "EducationNum", "MaritalStatus", "Occupation",
                "Relationship", "Race", "Gender",
                "CapitalGain", "CapitalLoss", "HoursPerWeek", "NativeCountry", "Income"]

    my_train_data = pd.read_csv("train.csv", names=col_name)

    train_data_top = my_train_data.head(10)

    train_data_down = my_train_data[10:999]

    test_set = train_data_top
    train_set = train_data_down

    test_data = test_set.values.tolist()

    train_data = train_set.values.tolist()

    k = 3

    length_test_data = len(test_data)
    everybodys_neighbours = []
    for i in range(length_test_data):
        everybodys_neighbours.append(neighbour(train_data, test_data[i], k))

    missing_class = []
    for i in test_data:
        missing_data = []
        for key, value in enumerate(i):
            if (value == '?'):
                missing_data.append(key)
        missing_class.append(missing_data)

    for row_index, row in enumerate(everybodys_neighbours):
        for col_number in missing_class[row_index]:
            missing_value = missing(row, col_number)
            test_data[row_index][col_number] = missing_value
    # print("\n the predicted training data is :  \n",test_data)

    actual_train_data = test_data
    actual_test_data = pd.read_csv("test.csv")
    testing_data = actual_test_data.values.tolist()
    #     print(testing_data)
    #     print(actual_train_data)
    #     print(actual_test_data)
    part_2 = knn(actual_train_data, testing_data)

if __name__ == '__main__':
    main()
