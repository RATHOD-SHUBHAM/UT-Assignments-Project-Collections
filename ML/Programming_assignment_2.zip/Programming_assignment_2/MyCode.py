'''
Note :
    Use Python Version 3.6
    numpy
    pandas 0.21
    scipy


Using a wrong version leads to code crash


Note: Large data set takes a long time to run. almost 15-20 min


increase step value for more accuracy but thea time increases




Warning says: you try to take the natural logarithm of a negative number. This will result in a NaN.
Depending on the function used, you will be presented with a range of errors.
'''


# Todo: All the import Lib are here
import numpy as np
import pandas as pd
from typing import List
from scipy.spatial.distance import correlation

# todo: matrix factorization
def matrixFactorization(R, K, steps=10, gamma=0.001,lamda=0.02):
    N = len(R.index)
    M = len(R.columns)
    P = pd.DataFrame(np.random.rand(N,K),index=R.index)
    Q = pd.DataFrame(np.random.rand(M,K),index=R.columns)
    for step in range(steps):
        for i in R.index:
            for j in R.columns:
                if R.loc[i,j]>0:
                    eij = R.loc[i,j]-np.dot(P.loc[i],Q.loc[j])
                    P.loc[i] = P.loc[i]+gamma*(eij*Q.loc[j]-lamda*P.loc[i])
                    Q.loc[j] = Q.loc[j]+gamma*(eij*P.loc[i]-lamda*Q.loc[j])
        e = 0
        for i in R.index:
            for j in R.columns:
                if R.loc[i,j]>0:
                    e = e + pow(R.loc[i,j]-np.dot(P.loc[i],Q.loc[j]),2)+lamda*(pow(np.linalg.norm(P.loc[i]),2)+pow(np.linalg.norm(Q.loc[j]),2))
        if e < 0.001:
            break
        print(step)
    return P,Q


#todo: computing Similarity between two users
def twoUser(usr1, usr2):
    usr1 = np.array(usr1) - np.nanmean(usr1)
    usr2 = np.array(usr2) - np.nanmean(usr2)
    movieIds = [i for i in range(len(usr1)) if usr1[i] > 0 and usr2[i] > 0]
    if len(movieIds) == 0:
        return 0
    else:
        usr1 = np.array([usr1[i] for i in movieIds])
        usr2 = np.array([usr2[i] for i in movieIds])
        return correlation(usr1, usr2)

#todo: Computing Nearest Neighbours
def nearestNeighbour(MatrixRating, activeUser: int, K: int):
    similarMatrix = pd.DataFrame(index=MatrixRating.index, columns=['Similarity'])
    for i in MatrixRating.index:
        similarMatrix.loc[i] = twoUser(MatrixRating.loc[activeUser], MatrixRating.loc[i])
    similarMatrix = pd.DataFrame.sort_values(similarMatrix, ['Similarity'], ascending=[0])

    nearestNeighbours = similarMatrix[:K]

    neighbourRatings = MatrixRating.loc[nearestNeighbours.index]

    predictItemRating = pd.DataFrame(index=MatrixRating.columns, columns=['Rating'])

    for i in MatrixRating.columns:
        # for each item
        predictedRating = np.nanmean(MatrixRating.loc[activeUser])
        # start with the average rating of the user
        for j in neighbourRatings.index:
            # for each neighbour in the neighbour list
            if MatrixRating.loc[j, i] > 0:
                predictedRating += (MatrixRating.loc[j, i] - np.nanmean(MatrixRating.loc[j])) * nearestNeighbours.loc[
                    j, 'Similarity']
        predictItemRating.loc[i, 'Rating'] = predictedRating
    return predictItemRating


#todo Perform Validation
def k_fold_cross_validation(dataset, n_folds):
    dataset_split = list()
    dataset_copy = list(dataset)
    #     print(len(dataset)) == 150
    fold_size = int(len(dataset) / n_folds)
    #     print(fold_size) == 30
    for _ in range(n_folds):
        fold = list()
        while len(fold) < fold_size:
            index = r.randrange(len(dataset_copy))
            fold.append(dataset_copy.pop(index))
        #             https://www.geeksforgeeks.org/python-list-pop
        #             print("fold value is: ",fold)
        dataset_split.append(fold)
    return dataset_split



# todo: Top Recommender
def topRec(matrixRating, movieData, activeUser: int, N: int, NumberOfNeighbours: int) -> List:
    predictRating = nearestNeighbour(matrixRating,activeUser, NumberOfNeighbours)
    moviesAlreadyWatched = list(matrixRating.loc[activeUser].loc[matrixRating.loc[activeUser] > 0].index)
    predictRating = predictRating.drop(moviesAlreadyWatched)
    topRecommendations = pd.DataFrame.sort_values(predictRating, ['Rating'], ascending=[0])[:N]
    topRecommendationTitles = (movieData.loc[movieData.movieId.isin(topRecommendations.index)])
    return list(topRecommendationTitles.title)


# todo: Top Favourite Movie
def topNfavoriteMovies(ratingData, activeUser: int, N: int) -> List:
    topMovies = pd.DataFrame.sort_values(ratingData[ratingData.userId == activeUser], ['rating'], ascending=[0])[:N]
    return list(topMovies.title)

# todo: ReadFile
def readFile(Filename):
    if Filename == 'smallratings.csv':
        ratingData = pd.read_csv(Filename, usecols=['userId', 'movieId', 'rating'])
        return ratingData
    else:
        movieData = pd.read_csv(Filename, usecols=['movieId', 'title'])
        return movieData

#todo: Main program where user will provide input
def main():
    # enter =  10
    print("Example 10: So 10 neighbours will be selected")
    NumberOfNeighbours = int(input("Enter the number of neighbours you want to select: "))
    # read the rating csv file into a dataframe
    ratingFile = 'smallratings.csv'
    ratingData = readFile(ratingFile)
    # print(ratingData.head())

    # read movie csv file
    movieInfoFile = "smallmovies.csv"
    movieData = readFile(movieInfoFile)

    # print(movieData.head())


    # joining column from different csv into single csv
    # adds title to rating data
    ratingData = pd.merge(ratingData, movieData, left_on='movieId', right_on="movieId")

    # userIdsObject = ratingData.userId  # a Pandas series object
    # userIdsDf = ratingData[['userId']]  # a Pandas DataFrame object

    # print(userIdsObject.head())
    # print(userIdsDf.head())

    ratingData.loc[0:10, ['userId']]
    # Sort data on columns [ 'userId', 'movieId' ]  in ascending order
    print('example: Toy Story (1995)','M*A*S*H (a.k.a. MASH) (1970)', 'Excalibur (1981)', 'Indiana Jones and the Last Crusade (1989)')
    print("If given a wrong input -- > error will be popped")
    print("\n")
    MovieName = input("Enter A Movie Name Of Your Choice: ")
    toyStoryUsers = ratingData[ratingData.title == MovieName ]
    # print(toyStoryUsers['userId'].values[0])

    ratingData = pd.DataFrame.sort_values(ratingData, ['userId', 'movieId'], ascending=[0, 1])

    # panda pivot table function
    matrixRating = pd.pivot_table(ratingData, values='rating', index=['userId'], columns=['movieId'])
    print("Generating Matrix")
    print(matrixRating.head())

    activeUser = toyStoryUsers['userId'].values[0]
    # top_Recommendations = topRec(matrixRating,movieData ,activeUser, 3,NumberOfNeighbours)
    # User top rated movies and his recommeddation
    print("\n\n")
    print("Example:  enter 3 , and top 3 fav movie will be selected")
    Nfav = int(input("Enter The Number Of fav movies you wanna select: "))
    print("\n")
    print("Example:  enter 5 , to get top 5 recommendation ")
    NumberOfRecommendationtobefetched = int(input("Enter the number of recommendation you wanna see based on your choice: "))
    print("\n")

    print("User Fav Movie for which he has giving highest rating: ")
    print(topNfavoriteMovies(ratingData, activeUser, Nfav))

    print("\n")

    print("Top Recommended movie with KNN and without matrix factor are:  ")
    print(topRec(matrixRating,movieData ,activeUser, NumberOfRecommendationtobefetched, NumberOfNeighbours))


    # print("\n\n")


    print("Predicting Movies using Matrix Factorizaton")

    # increase step value for more accuracy but the run time increases
    # matrix rating should run on entire dataset but that takes a lot of time so restricting it to first 100 users
    # steps loop through rating N times

    (P, Q) = matrixFactorization(matrixRating.iloc[:100, :100], K=2, gamma=0.001, lamda=0.02, steps=2)

    activeUser = toyStoryUsers['userId'].values[0]
    predictItemRating = pd.DataFrame(np.dot(P.loc[activeUser], Q.T), index=Q.index, columns=['Rating'])
    topRecommendations = pd.DataFrame.sort_values(predictItemRating, ['Rating'], ascending=[0])[:NumberOfRecommendationtobefetched]


    # We found the ratings of all movies by the active user and then sorted them to find the top 3 movies
    topRecommendationTitles = movieData.loc[movieData.movieId.isin(topRecommendations.index)]
    print("\n\n")
    print("Movie Recommendation are: ")
    print(list(topRecommendationTitles.title))


if __name__ == '__main__':
    main()
