======================================================  Machine Learning ==================================================================

====================================================== Progamming Assignment 1 =============================================================

				Name : Shubham Shankar
				UTA ID : 1001761068
				Section: 2208 - CSE - 6363 - 004

========================================================================================================================================


	Zip File Name : Programming_assignment.

		1. Extract the file.

	Once the content from is extracted the file contains:
	
		1. Anaconda Folder
		2.Knn Report
		3. Read Me
		4. Python Folder

========================================================================================================================================

							To run the code as .ipynb
			* Note: In order to run the program all the csv file and code must be in the same folder

	1. Open the folder named Anaconda.
	2. Folder contains:
		i. Assignment.ipynb
		ii. Car csv
		iii. Hayes-roth csv
		iv. Breast-cancer csv
		v. Iris.csv

	-  Run assignment.ipynb file in Jupyter Notebook.
	- Click on run all cell.
	- Then code will ask to enter a input for type of dataset. (Eg: 1- car.csv. 2. Hayes-roth etc)
	- Once you enter you will be given the  vectorized form of class and prediction result.


		* In order to know the predicted class label uncomment the last few lines of code

========================================================================================================================================
				
							To run the code as .py
			* Note: In order to run the program all the csv file and code must be in the same folder

	1. Open the folder named python in pycharm(preferred)
	2. Folder contains:
		i. KNN.py
		ii. Car csv
		iii. Hayes-roth csv
		iv. Breast-cancer csv
		v. Iris.csv

	-  Run KNN.py file in pycharm(preferred) else on terminal.
	- Click on run .
	- Then code will ask to enter a input for type of dataset. (Eg: 1- car.csv. 2. Hayes-roth etc)
	- Once you enter you will be given the  vectorized form of class and prediction result.


		* In order to know the predicted class label uncomment the last few lines of code

========================================================================================================================================
