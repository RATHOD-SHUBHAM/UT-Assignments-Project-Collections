<?php
	session_start();
   include 'database_connection.php';


// --------------------- contact me validation --------------

$c_validate = "";

if(isset($_POST['contact_submit'])){
	$NAME = $_POST['NAME'];
	$EMAIL = $_POST['EMAIL'];
	$MESSAGE = $_POST['MESSAGE'];

	$SEND_MAIL = "assigtext@gmail.com";
	$INFO = "INTRESTED!!! PLEASE REVERT BACK";
	$CONTENT = "NAME: ".$NAME."\n"."EMAIL: ".$EMAIL."\n"."MESSAGE: ".$MESSAGE;
	$FROM = "FROM: ".$EMAIL;
	

	if(empty($NAME) || empty($EMAIL) || empty($MESSAGE)) {
	    $c_validate = "compulsary";
	  } 

	  else {
	    if(strlen($NAME) >= 255 || !preg_match("/^[a-zA-Z-'\s]+$/", $NAME)) {
	      $c_validate = " enter  valid name";
	    }

	    else if(!filter_var($EMAIL, FILTER_VALIDATE_EMAIL)) {
	      $c_validate = "enter  valid email";
	    } 
	  

	      else{

	      $sql= "INSERT INTO CONTACT (NAME,EMAIL,MESSAGE ) VALUES (:NAME,:EMAIL,:MESSAGE)";
	      $result = $pdo->prepare($sql);
	      
	      $result->execute(['NAME'=>$NAME,'EMAIL'=>$EMAIL,'MESSAGE'=>$MESSAGE]);

	      if(mail($SEND_MAIL,$INFO,$CONTENT,$FROM)){
	      	$c_validate = " EMAIL RECEIVED";

	      }

	      else{
	      	$c_validate = "message sent";
	      }

	  
	      $NAME = "";
	      $MESSAGE = "";
	      $EMAIL = "";
	      }

    }
  }




// -----------login validation----------------
$log_validate = "";

if(isset($_POST['login_submit'])){
	$USER = $_POST['login_username'];
	$PASSWORD = $_POST['login_password'];
	

	if(empty($USER) || empty($PASSWORD) ) {
	    $log_validate = "Enter Username and password ";
	  } 

	else{
		$sqli = "select * from SIGN_IN where USER='$USER'";
		$log_result = $pdo->query($sqli);
		if($log_result->rowCount()>0){

			$row = $log_result->fetch();
			if(strval($PASSWORD)!= strval($row['PASSWORD'])){
				$log_validate = "incorrect_password";
			}
			else{
				$log_validate = "log-in successful";
				$_SESSION['USER'] = $row['USER'];
				$_SESSION['FIRST_NAME'] = $row['FIRST_NAME'];
				if($row['ACC_TYPE']== "ADMIN")
				{
					$_SESSION['ACC_TYPE'] = "ADMIN";
				}
				else
				{
					$_SESSION['ACC_TYPE'] = "NA";
				}
			}

		}

	}
}

	

// -----------------------sign up validation -----------------------
   $validate = "";
	if(isset($_POST['signup_submit'])){
	  $FIRST_NAME = $_POST['FIRST_NAME'];
	  $LAST_NAME = $_POST['LAST_NAME'];
	  $EMAIL = $_POST['EMAIL'];
	  $USER = $_POST['USER'];
	  $PASSWORD = $_POST['PASSWORD'];
	  $REPEAT_PASSWORD = $_POST['REPEAT_PASSWORD'];
	  $TYPE = "NA";

	  if(empty($FIRST_NAME) || empty($EMAIL) || empty($LAST_NAME) || empty($USER) || empty($PASSWORD) ||empty($REPEAT_PASSWORD) ) {
	    $validate = "compulsary.";
	  } 
	  else {
	    if(strlen($FIRST_NAME) >= 255 || !preg_match("/^[a-zA-Z-'\s]+$/", $FIRST_NAME)) {
	      $validate = " enter  valid input";
	    }

	     else if(strlen($LAST_NAME) >= 255 || !preg_match("/^[a-zA-Z-'\s]+$/", $LAST_NAME)) {
	      $validate = "enter  valid input";
	    } 

	    else if(!filter_var($EMAIL, FILTER_VALIDATE_EMAIL)) {
	      $validate = "enter  valid input";
	    } 

	    else 
	    {  
	      $sql = "SELECT * from SIGN_IN WHERE USER='$USER'";
	      $result = $pdo->query($sql);
	      if($result->rowCount()>0){
	      	$validate = "pick other user name";
	      }

	      else{

	      $sql1 = "INSERT INTO SIGN_IN (FIRST_NAME, LAST_NAME, EMAIL, USER, PASSWORD, REPEAT_PASSWORD, ACC_TYPE ) VALUES (:FIRST_NAME, :LAST_NAME, :EMAIL, :USER, :PASSWORD, :REPEAT_PASSWORD, :TYPE)";

	  

	      $result1 = $pdo->prepare($sql1);
	      
	      $result1->execute(["FIRST_NAME"=>$FIRST_NAME, "LAST_NAME"=>$LAST_NAME, "EMAIL"=>$EMAIL, "USER"=>$USER ,"PASSWORD"=>$PASSWORD, "REPEAT_PASSWORD"=>$REPEAT_PASSWORD , "TYPE" =>$TYPE]);
	      
	      $validate = "message sent";

	  
	      $FIRST_NAME = "";
	      $LAST_NAME = "";
	      $EMAIL = "";
	      $USER = "";
	      $PASSWORD = "";
	      $REPEAT_PASSWORD = "";
    	}

    }
  }
}

?>



<!DOCTYPE html>
<html>
<head>
	<title> SHUBHAM SHANKAR PORTFOLIO</title>
	<link rel="stylesheet" type="text/css" href="portfolio.css">
	<meta name='viewport' content='width=device-width, initial-scale=1.0'>
	<script src='https://kit.fontawesome.com/a076d05399.js'></script>
	<meta charset="utf-8">
	<script type="text/javascript" src="script.js"></script>
</head>
<body>						
	<div id = "wrapper">
		<div id = "container">			
			<div id = "my_head">
				<header>
					<nav class = "name">
						<ul>
							<li>SHUBHAM SHANKAR</li>
						</ul>
					</nav>
					<nav class = "nav_bar">
						<ul>
							<li><a href="home.php">HOME</a></li>
							<li><a href="my_skills.php">MY SKILLS</a></li>
							<li><a href="recomendation.php">RECOMMENDATION</a></li>

							<li><a href="work.php">WORK</a></li>
							<li><a href="http://shankarshubham.uta.cloud/BLOG/">BLOGS</a></li>
							<li><a href="hire_me.php">HIRE-ME</a></li>

							<?php if(!isset($_SESSION['USER'])):?>
							<li><a href="#" id="login-button">LOG-IN</a></li>
							<li><a href="#" id="signup-button">SIGN-UP</a></li>
							<?php endif; ?>

						<?php if((isset($_SESSION['USER']))&&(($_SESSION['ACC_TYPE'])=="ADMIN")): ?>
						<li><a href="admin.php" id="edit-button">EDIT</a></li>
						<li><a href="logout.php" id="logout-button">LOG-OUT</a></li>
						<?php endif; ?>

						<?php if((isset($_SESSION['USER']))&&(($_SESSION['ACC_TYPE'])!="ADMIN")): ?>
						<li><a href="logout.php" id="logout-button">LOG-OUT</a></li>
						<li><?php echo $_SESSION['USER']; ?></li>
						<?php endif; ?>
						
						</ul>	
					</nav>
				</header>
			</div>
			<div id = "my_main">
				<div class="welcome">
					<h1>Welcome to my website</h1>
				</div>
				<div class = "second_para">
					<pre>
							It is a great a great pleasure for me to receive your visit and
					that my professional information is of your liking and meets what you are looking for.
					</pre>
				</div>
				<div class="my_button">
					<a href="My Resume.pdf" download = "My Resume.pdf"><button type="button">DOWNLOAD RESUME   <i class='fas fa-download'></i></button></a>
				</div>
			</div>
		</div>
		<div id="login">

				<form action="#" method="POST" class="lcontent" name="Login">

					<div id="close">+</div>
					<div id="l_label">
						<label>Log-in :</label>
					</div>

					

					<div id="validate">
        				<?php echo $log_validate ?>
      				</div>

					<div id="logusername">
						<label>Username: </label>
						<input type="text" name="login_username" oninput="loginvalidate()" required>
						<div id="user_error"></div>
					</div>
					

					<div id="logpassword"> 
						<label>Password: </label>
						<input type="password" name="login_password" oninput="logpassword()" required>
						<div id = "l_password_error"></div>
					</div>
					
					
					<div id="logbutton">
					<a href="#" class="logclose"><button type="button">CANCEL</button></a>
					
					<button type="submit" name="login_submit" value="Submit" class="getin">SUBMIT</button> 

				</div>
			</form>	
		</div>

		<div id="signup">
			<form action="#" method="POST" class="scontent" name = "Signup" >

							<div id="sclose">+</div>

								<div id="Slabel">
									<label>Check in </label>
								</div>
								 <div id="svalidate">
        							<?php echo $validate ?>
      							</div>
								<div id="Susername">
									<label>First_Name:</label>
									<input type="text" name="FIRST_NAME"  pattern="[A-Za-z]{1,}" title="Enter Valid Name - Alphabets only" oninput="firstnamevalidate()" required>
									<div id="s_first_name"></div>
								</div>
								

								<div id="Spassword"> 
									<label>Last_Name:</label>
									<input type="text" name="LAST_NAME" pattern="[A-Za-z]{1,}" title="Enter Valid Name - Alphabets only" oninput="lastnamevalidate()" required>
									<div id="s_last_name"></div>
								</div>
								

								<div id="Spassword"> 
									<label>Email_id:</label>
									<input class="forminput" type="email" name="EMAIL" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Enter Valid Email - All lowercase & Alphanumeric - aaa@aaa.domain" oninput="emailvalidate()" required>
									<div id="email_error"></div>
								</div>
								

								<div id="Spassword"> 
									<label>Username:</label>
									<input type="text" name="USER" pattern="[A-Za-z0-9]{3,}" title="Enter Valid Username with  Minimum three Alphanumeric characters " oninput="uservalidate()" required>
									<div id="useerror"></div>
								</div>
								


								<div id="Spassword"> 
									<label>Password:</label>
									<input type="password" name="PASSWORD" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#\$%\^&\*]).{6,}" title="ontain at least one UpperCase, one LowerCase , one Number, one special character, and size must be atleast 6 or more characters" oninput="passwordvalidate()" required>
									<div id="password_error"></div>
								</div>
								

								<div id="Spassword"> 
									<label>Re-enter Password:</label>
									<input type="password" name="REPEAT_PASSWORD" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#\$%\^&\*]).{6,}" title="Contain at least one UpperCase, one LowerCase , one Number, one special character, and size must be atleast 6 or more characters" oninput="repasswordvalidate()" required>
									<div id="s_re_password_error"></div>
								</div>
								
								
								<div id="signbutton">
								<a href="#" class="Ssignup"><button type="button">CANCEL</button></a>
								
								<button type="submit" name = "signup_submit" value="Submit" class="getin">SUBMIT</button> 
							</div>
			</form>
		</div>
		<div id="contact">

				<form action="#" method="POST" class="c_content" name = "Contact">

					<div id="c_close">+</div>
					<div id="c_label">
						<label>HAVE A PROJECT TO DISCUSS :</label>
					</div>

					

					<div id="validate">
        				<?php echo $c_validate ?>
      				</div>

					<div id="c_logusername">
						<label>NAME: </label>
						<input type="text" name="NAME"  pattern="[A-Za-z]{1,}" title="Enter Valid Name - Alphabets only" oninput="contactvalidate()" required>
						<div id="conname"></div>
					</div>
					
					
					<div id="c_logpassword"> 
						<label>Email:</label>
						<input class="forminput" type="EMAIL" name="EMAIL" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Enter Valid Email - All lowercase & Alphanumeric - aaa@aaa.domain" oninput="conemailvalidate()"  required>
						<div id="emailerror"></div>
					</div>
					

					<div id="c_logpassword"> 
						<label>MESSAGE: </label>
						<textarea type="text" name="MESSAGE"  pattern="[A-Za-z]{1,}" title="Enter Valid Name - Alphabets only"
						oninput="convalidate()" required></textarea>
						<div id="conmessage"></div>
					</div>
					
					
					<div id="c_logbutton">
					<a href="#" class="c_logclose"><button type="button">CANCEL</button></a>
					
					<button type="submit" name="contact_submit" value="Submit" class="getin">SUBMIT</button> 

					</div>
				</form>	
		</div>



	</div>
	<div id = "my_foot">
		<footer>
			<nav class = "name1">
				<ul>
					<li>SHUBHAM SHANKAR</li>
				</ul>
			</nav>
			<nav class = "nav_bar1">
				<ul>
							<li><a href="home.php">HOME</a></li>
							<li><a href="my_skills.php">MY SKILLS</a></li>
							<li><a href="recomendation.php">RECOMMENDATION</a></li>
							
							<li><a href="work.php">WORK</a></li>
							<li><a href="http://shankarshubham.uta.cloud/BLOG/">BLOGS</a></li>
							<li><a href="hire_me.php">HIRE-ME</a></li>

							<?php if(!isset($_SESSION['USER'])):?>
							<li><a href="#" id="login-button">LOG-IN</a></li>
							<li><a href="#" id="signup-button">SIGN-UP</a></li>
							<?php endif; ?>

						<?php if((isset($_SESSION['USER']))&&(($_SESSION['ACC_TYPE'])=="ADMIN")): ?>
						<li><a href="admin.php" id="edit-button">EDIT</a></li>
						<li><a href="logout.php" id="logout-button">LOG-OUT</a></li>
						<?php endif; ?>

						<?php if((isset($_SESSION['USER']))&&(($_SESSION['ACC_TYPE'])!="ADMIN")): ?>
						<li><a href="logout.php" id="logout-button">LOG-OUT</a></li>
						<li><?php echo $_SESSION['USER']; ?></li>
						<?php endif; ?>
							<!-- <li><a href="home.php">HOME</a></li>
							<li><a href="my_skills.php">MY SKILLS</a></li>
							<li><a href="recomendation.php">RECOMMENDATION</a></li>
							<li><a href="works.html">WORK</a></li>
							<li><a href="http://shankarshubham.uta.cloud/BLOG/">BLOGS</a></li>
							<li><a href="hire_me.php">HIRE-ME</a></li>
							<li><a href="#" id="login-button1">LOG-IN</a></li>
							<li><a href="#" id="signup-button1">SIGN-UP</a></li> -->
							<li><a href="#" id="contactme">CONTACT_ME</a></li>
						</ul>	
			</nav>
		</footer>
	</div>

</body>
</html>