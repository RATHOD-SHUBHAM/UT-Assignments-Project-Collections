<?php 

session_start();

if(!isset($_SESSION['USER']))
{
	header('location:home.php');
}

include 'database_connection.php';
$sql = "SELECT * from WORK WHERE 1";
$result = $pdo->prepare($sql);
$result->execute();

$array_data = array();

while($row = $result->fetch())	
{

	$array_data[] = $row;

}

?>


<!DOCTYPE html>
<html>
<head>
	<title> SHUBHAM SHANKAR PORTFOLIO</title>
	<link rel="stylesheet" type="text/css" href="portfolio.css">
	<meta name='viewport' content='width=device-width, initial-scale=1.0'>
	<script src='https://kit.fontawesome.com/a076d05399.js'></script>
	<meta charset="utf-8">
</head>
<body>						<!-- there is no much difference btn id and class -->
	<div id = "wrapper">
		<div id = "work">			<!-- id is used for something unique -->
			<div id = "my_head">
				<header>
					<nav class = "name"><!-- class can be used over and over again -->
						<ul>
							<li>SHUBHAM SHANKAR</li>
						</ul>
					</nav>
					<nav class = "nav_bar">
						<ul>
							<li><a href="home.php">HOME</a></li>
							<li><a href="my_skills.php">MY SKILLS</a></li>
							<li><a href="recomendation.php">RECOMMENDATION</a></li>
							<li><a href="work.php">WORK</a></li>
							<li><a href="http://shankarshubham.uta.cloud/BLOG/">BLOGS</a></li>
							<li><a href="hire_me.php">HIRE-ME</a></li>

							<?php if(!isset($_SESSION['USER'])):?>
							<li><a href="#" id="login-button">LOG-IN</a></li>
							<li><a href="#" id="signup-button">SIGN-UP</a></li>
							<?php endif; ?>

						<?php if((isset($_SESSION['USER']))&&(($_SESSION['ACC_TYPE'])=="ADMIN")): ?>
						<li><a href="admin.php" id="edit-button">EDIT</a></li>
						<li><a href="logout.php" id="logout-button">LOG-OUT</a></li>
						<?php endif; ?>

						<?php if((isset($_SESSION['USER']))&&(($_SESSION['ACC_TYPE'])!="ADMIN")): ?>
						<li><a href="logout.php" id="logout-button">LOG-OUT</a></li>
						<li><?php echo $_SESSION['USER']; ?></li>
						<?php endif; ?>
						
						</ul>		
					</nav>
				</header>
			</div>
			<div id="work_body">
				<nav class="latest_work">
					<h1>MY LATEST WORK</h1>
					<pre><?php echo $array_data[0]['WORK_DESC'] ?></pre>
					
					<button class="tablinks" id="download-button" onclick="openworks(event, 'show_all')">SHOW ALL</button>

					<button class="tablinks" id="download-button" onclick="openworks(event, 'website')">WEBSITE</button>

					<button class="tablinks" id="download-button" onclick="openworks(event, 'apps')">APPS</button>

					<button class="tablinks" id="download-button" onclick="openworks(event, 'design')">DESIGN</button>

					<button class="tablinks" id="download-button" onclick="openworks(event, 'photography')">PHOTOGRAPHY</button>


					<div class="wrow" id = "wrow1">

				            <div id="show_all" class="tabcontent">
				                <table id = "table" class = "table">
				                    <tr>
				                        <td> <img src="<?php echo $array_data[0]['WORK_IMG'] ?>" width: 30%; height="180px"> </td>
				                        <td>DIAZAPPS <br><br> Websites </td>

				                        <td> <img src="<?php echo $array_data[1]['WORK_IMG'] ?>" width: 30%; height="180px"> </td>
				                        <td>3D DESIGN <BR> Blender </td>

				                        <td> <img src="<?php echo $array_data[2]['WORK_IMG'] ?>"  width: 30%; height="180px"> </td>
				                        <td>PLAYER <BR><BR> Website </td>
				                    </tr>





				                    <tr>
				                        <td> <img src="<?php echo $array_data[3]['WORK_IMG'] ?>" width: 30%; height="180px"> </td>
				                        <td>MI ABC <br><br> Apps </td>

				                        <td> <img src="<?php echo $array_data[4]['WORK_IMG'] ?>" width: 30%; height="180px"> </td>
				                        <td> STAFF TRAINING <BR> Website </td>

				                        <td> <img src="<?php echo $array_data[5]['WORK_IMG'] ?>"  width: 30%; height="180px"> </td>
				                        <td>STAFF TRAINING <BR><BR> Apps </td>
				                    </tr>

				                    <tr>
				                        <td> <img src="<?php echo $array_data[6]['WORK_IMG'] ?>" width: 30%; height="180px"> </td>
				                        <td>3D DESIGN<br><br> Blender </td>

				                        <td> <img src="<?php echo $array_data[7]['WORK_IMG'] ?>" width: 30%; height="180px"> </td>
				                        <td> ASGARDIA ACADEMY <BR> website </td>

				                        <td> <img src="<?php echo $array_data[8]['WORK_IMG'] ?>"  width: 30%; height="180px"> </td>
				                        <td>EVENTS<BR><BR> Photography </td>
				                    </tr>
				                </table>
				            </div>


				            <div id="website" class="tabcontent">
				                <table>
				                    <tr>
				                        <td> <img src="<?php echo $array_data[0]['WORK_IMG'] ?>" width: 30%; height="180px"> </td>
				                        <td>DIAZAPPS <br><br> Websites </td>

				                        <td> <img src="<?php echo $array_data[2]['WORK_IMG'] ?>"  width: 30%; height="180px"> </td>
				                        <td>PLAYER <BR><BR> Website </td>
				                    </tr>
				                    <tr>
				                        <td> <img src="<?php echo $array_data[4]['WORK_IMG'] ?>" width: 30%; height="180px"> </td>
				                        <td> STAFF TRAINING <BR> Website </td>
				                    </tr>

				                    <tr>
				                        <td> <img src="<?php echo $array_data[7]['WORK_IMG'] ?>" width: 30%; height="180px"> </td>
				                        <td> ASGARDIA ACADEMY <BR> website </td>
				                    </tr>
				                </table>
				            </div>


				            <div id="apps" class="tabcontent">
				                <table>
				                    <tr>
				                        <td> <img src="<?php echo $array_data[3]['WORK_IMG'] ?>" width: 30%; height="180px"> </td>
				                        <td>MI ABC <br><br> Apps </td>

				                        <td> <img src="<?php echo $array_data[5]['WORK_IMG'] ?>"  width: 30%; height="180px"> </td>
				                        <td>STAFF TRAINING <BR><BR> Apps </td>
				                    </tr>
				                </table>
				            </div>

				            <div id="design" class="tabcontent">
				                <table>
				                    <tr>
				                        <td> <img src="<?php echo $array_data[1]['WORK_IMG'] ?>" width: 30%; height="180px"> </td>
				                        <td>3D DESIGN <BR> Blender </td>
				                    </tr>

				                    <tr>
				                        <td> <img src="<?php echo $array_data[6]['WORK_IMG'] ?>" width: 30%; height="180px"> </td>
				                        <td>3D DESIGN<br><br> Blender </td>
				                    </tr>
				                </table>
				            </div>


				            <div id="photography" class="tabcontent">
				                <table>
				                    <tr>
				                        <td> <img src="<?php echo $array_data[8]['WORK_IMG'] ?>"  width: 30%; height="180px"> </td>
				                        <td>EVENTS<BR><BR> Photography </td>
				                    </tr>
				                </table>
				            </div>


					</div>     <!-- #row div -->
				</nav>
        <script>
        	window.onload = function(){
        		document.querySelector('.wrow').style.display = "none";
        		var fun = openwork(event,"show_all");
        		function openworks(evt, work) {
	            // Declare all variables
		            var i, tabcontent, tablinks;

		            // Get all elements with class="tabcontent" and hide them
		            tabcontent = document.getElementsByClassName("tabcontent");
		            for (i = 0; i < tabcontent.length; i++) {
		              tabcontent[i].style.display = "none";
		            }

		            // Get all elements with class="tablinks" and remove the class "active"
		            tablinks = document.getElementsByClassName("tablinks");
		            for (i = 0; i < tablinks.length; i++) {
		              tablinks[i].className = tablinks[i].className.replace(" active", "");
		            }

		            // Show the current tab, and add an "active" class to the button that opened the tab
		            document.getElementById(work).style.display = "block";
		            evt.currentTarget.className += " active";
	          }

        	}
	          function openworks(evt, work) {
	            // Declare all variables
	            var i, tabcontent, tablinks;
	            document.querySelector('.wrow').style.display = "grid";

	            // Get all elements with class="tabcontent" and hide them
	            tabcontent = document.getElementsByClassName("tabcontent");
	            for (i = 0; i < tabcontent.length; i++) {
	              tabcontent[i].style.display = "none";
	            }

	            // Get all elements with class="tablinks" and remove the class "active"
	            tablinks = document.getElementsByClassName("tablinks");
	            for (i = 0; i < tablinks.length; i++) {
	              tablinks[i].className = tablinks[i].className.replace(" active", "");
	            }

	            // Show the current tab, and add an "active" class to the button that opened the tab
	            document.getElementById(work).style.display = "block";
	            evt.currentTarget.className += " active";
	          }
          
        </script>
				
			</div>
		</div>
	</div>
	<div id = "my_foot7">
		<footer>
			<nav class = "name">
				<ul>
					<li>SHUBHAM SHANKAR</li>
				</ul>
			</nav>
			<nav class = "nav_bar1">
				<ul>
					<li><a href="home.php">HOME</a></li>
							<li><a href="my_skills.php">MY SKILLS</a></li>
							<li><a href="recomendation.php">RECOMMENDATION</a></li>
							
							<li><a href="work.php">WORK</a></li>
							<li><a href="http://shankarshubham.uta.cloud/BLOG/">BLOGS</a></li>
							<li><a href="hire_me.php">HIRE-ME</a></li>

							<?php if(!isset($_SESSION['USER'])):?>
							<li><a href="#" id="login-button">LOG-IN</a></li>
							<li><a href="#" id="signup-button">SIGN-UP</a></li>
							<?php endif; ?>

						<?php if((isset($_SESSION['USER']))&&(($_SESSION['ACC_TYPE'])=="ADMIN")): ?>
						<li><a href="admin.php" id="edit-button">EDIT</a></li>
						<li><a href="logout.php" id="logout-button">LOG-OUT</a></li>
						<?php endif; ?>

						<?php if((isset($_SESSION['USER']))&&(($_SESSION['ACC_TYPE'])!="ADMIN")): ?>
						<li><a href="logout.php" id="logout-button">LOG-OUT</a></li>
						<li><?php echo $_SESSION['USER']; ?></li>
						<?php endif; ?>
					<li><a href="#" id="contactme">CONTACT_ME</a></li>
				</ul>	
			</nav>
		</footer>
	</div>
</body>
</html>