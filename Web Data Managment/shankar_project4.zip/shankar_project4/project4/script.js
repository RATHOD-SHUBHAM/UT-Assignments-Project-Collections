window.onload = function (){

document.getElementById('login-button').addEventListener('click',
	function(){
		document.querySelector('#login').style.display = 'grid';
	});


document.getElementById('signup-button').addEventListener('click',
	function(){
		document.querySelector('#signup').style.display = 'grid';
	});

document.querySelector('#close').addEventListener('click',
	function(){
		document.querySelector('#login').style.display = 'none';
	});


document.querySelector('#sclose').addEventListener('click',
	function(){
		document.querySelector('#signup').style.display = 'none';
	});

document.querySelector('.logclose').addEventListener('click',
	function(){
		document.querySelector('#login').style.display = 'none';
	});

document.querySelector('.Ssignup').addEventListener('click',
	function(){
		document.querySelector('#signup').style.display = 'none';
	});

document.getElementById('contactme').addEventListener('click',
	function(){
		document.querySelector('#contact').style.display = 'grid';
	});

document.querySelector('#c_close').addEventListener('click',
	function(){
		document.querySelector('#contact').style.display = 'none';
	});
document.querySelector('.c_logclose').addEventListener('click',
	function(){
		document.querySelector('#contact').style.display = 'none';
	});


document.getElementById('login-button1').addEventListener('click',
	function(){
		document.querySelector('#login').style.display = 'grid';
	});


document.getElementById('signup-button1').addEventListener('click',
	function(){
		document.querySelector('#signup').style.display = 'grid';
	});


}


function firstnamevalidate(){
	var firstnamedisplay = document.getElementById('s_first_name');
	var firstname = document.Signup.FIRST_NAME;
	var regularexp = /^[A-Za-z]{1,}$/;
	if(firstname.value.length>1){
		firstnamedisplay.innerHTML = " ";
		if(regularexp.test(firstname.value)){
			firstnamedisplay.innerHTML = " ";
		}
	
		else{
			firstnamedisplay.innerHTML = "ONLY LETTERS!!!!!!";
		}
	}
	else{
		firstnamedisplay.innerHTML = "MORE THAN ONE CHARACTER"
	}
}

function lastnamevalidate(){
	var lastnamedisplay = document.getElementById('s_last_name');
	var lastname = document.Signup.LAST_NAME;
	var regularexp = /^[A-Za-z]{1,}$/;
	if(lastname.value.length>1){
		lastnamedisplay.innerHTML = "";
		if(regularexp.test(lastname.value)){
			lastnamedisplay.innerHTML = " ";
		}
		else{
			lastnamedisplay.innerHTML = "ONLY LETTERS!!!!!!";
		}
	}
	else{
		lastnamedisplay.innerHTML = "MORE THAN ONE CHARACTER"
	}

}


function emailvalidate(){
	var emaildisplay = document.getElementById('email_error');
	var email = document.Signup.EMAIL;
	var regularexp = /^[a-zA-Z0-9\.-]+@+[a-zA-Z]+(\.)+[a-zA-Z]{2,3}$/;
	if(regularexp.test(email.value)){
		emaildisplay.innerHTML = "";
	}
	else{
		emaildisplay.innerHTML = "email should contain lowercase uppercase and alpha numeric value";
	}
}


function uservalidate(){
	var usedisplay = document.getElementById('useerror');
	var usename = document.Signup.USER;
	var regularexp = /^[a-zA-Z0-9]{1,}$/;
	if(usename.value.length>6){
		usedisplay.innerHTML = "";
		if(regularexp.test(usename.value)){
			usedisplay.innerHTML="";
		}
		else{
			usedisplay.innerHTML = " NO SPECIAL CHARACTER";
		}
	}
	else{
		usedisplay.innerHTML = "MORE THAN A CHARACTER";
	}
}

function passwordvalidate(){
	var passworddisplay = document.getElementById('password_error');
	var passwordname = document.Signup.PASSWORD;
	var regularexp = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20}$/;
	if(passwordname.value.length>6){
		passworddisplay.innerHTML = "";
		if(regularexp.test(passwordname.value)){
			passworddisplay.innerHTML="";
		}
		else{
			passworddisplay.innerHTML = "MUST CONTAIN UPPER CASE LOWER CASE NUMBER ONE SPECIAL CHARACTER AND MUST BE MORE THAN 6";
		}
	}
	else{
		passworddisplay.innerHTML = "MORE THAN 6 CHARACTER";
	}
}


function repasswordvalidate(){
	var repassworddisplay = document.getElementById('s_re_password_error');
	var repasswordname = document.Signup.PASSWORD;
	var repassword = document.Signup.REPEAT_PASSWORD;
	if(repassword.value == repasswordname.value){
		repassworddisplay.innerhtml = "password match";
	}
	else{
		repassworddisplay.innerhtml = "password doesnot match";
	}
}

// ----------------------- log in validation ------------------
function loginvalidate(){
	var userlogin = document.getElementById('user_error');
	var username = document.Login.login_username;
	var regularexp = /^[a-zA-Z0-9]{1,}$/;
	if(username.value.length>1){
		userlogin.innerHTML = "";
		if(regularexp.test(username.value)){
			userlogin.innerHTML = "";
		}
		else{
			userlogin.innerHTML = "should contain element";
		}
	}
	else{
		userlogin.innerHTML = "must contain more than one character";
	}
}

function logpassword(){
	var loginpassword = document.getElementById('l_password_error');
	var logpasswordname = document.Login.login_password;
	var regularexp = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20}$/
	if(logpasswordname.value.length>6){
		loginpassword.innerHTML = "";
		if(regularexp.test(logpasswordname.value)){
			loginpassword.innerHTML = "";
		}
		else{
			loginpassword.innerHTML = "should contain a upper lower and special character";
		}
	}
	else{
		loginpassword.innerHTML = "must contain more than six character";
	}
}

// ------------------ contact page ------------------------


function contactvalidate(){
	var userlogin = document.getElementById('conname');
	var username = document.Contact.NAME;
	var regularexp = /^[a-zA-Z0-9]{1,}$/;
	if(username.value.length>1){
		userlogin.innerHTML = "";
		if(regularexp.test(username.value)){
			userlogin.innerHTML = "";
		}
		else{
			userlogin.innerHTML = "should contain element";
		}
	}
	else{
		userlogin.innerHTML = "must contain more than one character";
	}
}

function conemailvalidate(){
	var emaildisplay = document.getElementById('emailerror');
	var email = document.Contact.EMAIL;
	var regularexp = /^[a-zA-Z0-9\.-]+@+[a-zA-Z]+(\.)+[a-zA-Z]{2,3}$/;
	if(regularexp.test(email.value)){
		emaildisplay.innerHTML = "";
	}
	else{
		emaildisplay.innerHTML = "email should contain lowercase uppercase and alpha numeric value";
	}
}

function convalidate(){
	var userlogin = document.getElementById('conmessage');
	var username = document.Contact.MESSAGE;
	var regularexp = /^[a-zA-Z0-9]{1,}$/;
	if(username.value.length>1){
		userlogin.innerHTML = "";
		if(regularexp.test(username.value)){
			userlogin.innerHTML = "";
		}
		else{
			userlogin.innerHTML = "should contain element";
		}
	}
	else{
		userlogin.innerHTML = "must contain more than one character";
	}
}

