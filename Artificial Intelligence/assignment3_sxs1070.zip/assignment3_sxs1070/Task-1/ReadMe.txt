
----------------------------------- Read Me ------------------------------------
Language used : Python3
Code written on PyCharm IDE
And ran on PyCharm terminal

--------------------------- CODE STRUCTURE -----------------------------------
The class minimax does the decision . Maxconnect4.py does perform min max and alpha beta pruning to find the result.

---------------------COMPILATION AND EXECUTION------------------------------------
	To run the code, navigate to task-1 in your PyCharm 
	execute python3 maxconnect4.py with standard python compilation commands.
 
	For interactive mode, pass the following arguments:
		python3 maxconnect4.py interactive [input_file] [computer-next/human-next] [depth]

	For one-move mode, pass the following arguments:
		python3 maxconnect4.py one-move [input_file] [output_file] [depth]	
