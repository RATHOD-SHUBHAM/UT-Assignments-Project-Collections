import sys
distance = []
heu_distance = []
fringe = []
result = 0
max_node_in_memory = 0
nodes = 0
nodes_produced = 0
visited_node = []


# ToDo : Reading uninformed file
def read_file(file_name):
    global distance
    read_file = open(file_name, "r")

    if read_file == None:
        print(" File doesnot exist")
    else:
        for i in read_file:
            lists = i.split()
            # todo : reading from a list and storing in another list so as to get the ending condition
            if lists[0] == "END":
                break
            else:
                distance.append(lists)
    read_file.close()


# todo : reading the heuristic file
def read_heu_file(heu_file_name,heuristic_file):
    global heu_distance
    read_heur_file = open(heuristic_file,"r")

    if read_heur_file == None:
        print(" file doesnot exist")
    else:
        for i in read_heur_file:
            heu_lists = i.split()

            # todo : reading from a list and storing in another list so as to get the ending condition
            if heu_lists[0] == "END":
                break
            else:
                heu_distance.append(heu_lists)
    read_heur_file.close()

#Todo : reading input1 .txt
    read_file = open(heu_file_name, "r")

    if read_file == None:
        print(" File doesnot exist")
    else:
        for i in read_file:
            lists = i.split()
            # todo : reading from a list and storing in another list so as to get the ending condition
            if lists[0] == "END":
                break
            else:
                distance.append(lists)
    read_file.close()




#Todo : Initialization part
class Node:
    def __init__(self,source,parent,cost):
        self.source = source
        self.cost = cost

        #todo : if parent is not empty
        if parent:
            self.cumulative_cost = int(cost) + int(parent.cumulative_cost)
            # print("cumulative cost if not empty : ", self.cumulative_cost)
        else:
            self.cumulative_cost = int(cost) # removing zero from here
            # print("cumulative cost if empty : ", self.cumulative_cost)

        if len(sys.argv) == 5:
            for i in heu_distance:
                if self.source == i[0]:
                    self.all_cost = self.cumulative_cost + int(i[1])
                    break
        self.parent = parent



#Todo : trace back the nodes
def trace_path(goal_node):
    print("Nodes expanded : ", nodes)
    print("Nodes generated : ", nodes_produced)
    print("Max node in memory : ", max_node_in_memory)

    if goal_node == "no_path":
        print("distance : infinity")
        print("route: None")

    else:
        final = []
        traversed_distance = 0
        present = goal_node

        while present.parent is not None:
            parent = present.parent
            final.append([parent.source, present.source, present.cost])
            traversed_distance = traversed_distance + int(present.cost)
            present = parent

        final.reverse()
        print("distance: ",traversed_distance,".0 KM")
        print("route: \n")
        for i in final:
            print(i[0] + " to " + i[1] + "," + i[2]+".0 KM")



# Todo : Check if the node is a destination
def goal(destination):
    adjacent_node = fringe[0]
    if adjacent_node.source == destination:
        return adjacent_node
    else:
        return None



# Todo :  Main Algorithm
def ui_algorithms(source, destination):
    global nodes
    global nodes_produced
    global max_node_in_memory
    global visited_node

    # todo : initilize node
    initilize_node = Node(source,None,0)
    fringe.append(initilize_node)
    max_node_in_memory = max_node_in_memory + 1

    while(len(fringe) != 0 ):
        nodes = nodes + 1
        goal_node = goal(destination)
        if goal_node:
            # print(" in here")
            trace_path(goal_node)
            break
        else:
            adjacent_node = fringe.pop(0)
            if adjacent_node.source not in visited_node:
                # print("innn  here")
                # print("distance is : ",distance)
                for i in distance:
                    # print("am here")
                    # print("i : ", i)
                    # print("distance : ", distance)
                    if i[0] == adjacent_node.source:
                        # print("am herereerer")
                        child = Node(i[1], adjacent_node ,i[2])
                        fringe.append(child)
                        nodes_produced = nodes_produced + 1

                    elif i[1] == adjacent_node.source:
                        child = Node(i[0], adjacent_node ,i[2])
                        fringe.append(child)
                        nodes_produced = nodes_produced + 1
                visited_node.append(adjacent_node.source)

            if len(fringe) > max_node_in_memory:
                max_node_in_memory = len(fringe)

            if (len(sys.argv) == 5):
                fringe.sort(key=lambda x: x.all_cost)
            else:
                fringe.sort(key=lambda x: x.cumulative_cost)

    if(len(fringe) == 0):
        # print(" here in ul algorithm fringe len == 0 ")
        trace_path("no_path")



# Todo : Main Function
def main():

    # todo : reading the command line argument
    length_of_argument = len(sys.argv)
    # print("The arguments are: ", str(sys.argv))
    # print("The length of the argument is : ", length_of_argument)

    # todo : this is for uninformed search
    if length_of_argument == 4:
        heuristic_file = None
        # Todo : storing each value of the command line in variables

        file_name = sys.argv[1]
        source = sys.argv[2]
        destination = sys.argv[3]

        # print("the file name is : ", file_name)
        # print("the source name is : ", source)
        # print("the destination name is : ", destination)

        # Todo : reading data from input1.txt
        read_file(file_name)

        #todo :  call the algorithm
        ui_algorithms(source,destination)

        # todo : this will be with heuristic file
    elif length_of_argument == 5:
        heu_file_name = sys.argv[1]
        heu_source = sys.argv[2]
        heu_destination = sys.argv[3]
        heuristic_file = sys.argv[4]
        # print("the file name is : ", heu_file_name)
        # print("the source name is : ", heu_source)
        # print("the destination name is : ", heu_destination)
        # print("the heuristic_file is : ", heuristic_file)

        # Todo : reading data from input1.txt
        read_heu_file(heu_file_name,heuristic_file)

        # Todo : call the algorithm
        ui_algorithms(heu_source, heu_destination)


if __name__ == "__main__":
    main()
